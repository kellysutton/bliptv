class OpenStruct #:nodoc:
  
  def table
    @table
  end
  
end